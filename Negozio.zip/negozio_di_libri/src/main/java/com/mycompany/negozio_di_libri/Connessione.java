/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.negozio_di_libri;

/**
 *
 * @author marco
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.*;




/**
 *
 * @author aless
 */
public class Connessione {
    
    public Connessione() {
        System.out.println("Classe gestisce connessione");
    }
    
    public static Connection testConnessione()
    {
        try {
            // Carica il driver JDBC
            Class.forName("org.sqlite.JDBC");

            // Stabilisce la connessione al database
            Connection connection = DriverManager.getConnection("jdbc:sqlite:negozio_di_libri_ DATA.db");
            System.out.println("Connessione Eseguita");
            return connection;
        } catch(Exception e){
            System.out.println("Connessione Fallita"+ e);
            return null;
        }
        
    }
    
}
